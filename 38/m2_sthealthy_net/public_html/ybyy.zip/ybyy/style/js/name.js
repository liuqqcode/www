var name = '宜昌市夷陵区时作霖医院';
var address = '<span class="s_txt">医院地址：宜昌市夷陵区夷兴大道36号</span>';
var tel = '<span class="s_txt">咨询电话：0717-7819111</span>';
