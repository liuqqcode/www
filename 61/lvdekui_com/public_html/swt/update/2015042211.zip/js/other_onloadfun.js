//页面连接处理
$$$(function(){
	var alllink = document.links;		//获取页面所有连接
	for(var i=0;i<alllink.length;i++){
		if(alllink[i].href.indexOf("tel:")>-1){
			alllink[i].target = "_blank";		//设置电话连接为新窗口打开
			alllink[i].href = "{dhurl}";		//替换电话连接为系统设置的连接
		}
		if({isaonclick}==0){
			if(alllink[i].getAttribute('href',2)=="{swtdir}" || alllink[i].getAttribute('href',2)=="{swtdir}/"){
				alllink[i].target = "_blank";		//设置商务通连接为新窗口打开
				//给无参数连接加上gotoswt(event,this)，需JQ支持
				if(!$(alllink[i]).attr("onclick")){
					$(alllink[i]).attr("onclick","gotoswt(event,this);");
				}
			}
		}
	}
	//自动弹出QQ聊天窗口
	if({isopenqqchat}!=0){
		setTimeout(function (){popwin=window.location.href="tencent://message/?Menu=yes&uin={qq}&Service=58"},1000 * {isopenqqchat});
	}
})