<?php
$isversion=2015042211;		//程序版本号
$uplisturl="http://js.cdmz.net/yycode/swt/update/";		//程序更新地址
?>