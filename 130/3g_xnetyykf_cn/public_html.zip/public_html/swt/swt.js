(function(m, ei, q, i, a, j, s) {
		m[i] = m[i] || function() {
				(m[i].a = m[i].a || []).push(arguments)
		};
		j = ei.createElement(q),
				s = ei.getElementsByTagName(q)[0];
		j.async = true;
		j.charset = 'UTF-8';
		j.src = 'https://static.meiqia.com/dist/meiqia.js?_=t';
		s.parentNode.insertBefore(j, s);
})(window, document, 'script', '_MEIQIA');
_MEIQIA('entId', 115900);

function openZoosUrl(chatwin,exp){
	_MEIQIA('showPanel');
	_MEIQIA('metadata', {address: exp });
}

//邀请框屏蔽
// document.writeln("<style>");
// document.writeln("#LRdiv0{ display:none!important;}");
// document.writeln("#LRdiv1{ display:none!important;}");
// document.writeln("#qiao-wrap{ display:none!important;}");
// document.writeln("#LXB_CONTAINER_SHOW{ display:none!important;}");
// document.writeln("#MEIQIA-INVITE{display: none!important;}");
// document.writeln("</style>");
